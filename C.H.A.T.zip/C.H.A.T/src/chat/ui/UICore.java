/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.ui;

import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 *
 * @author Chris
 */
public class UICore extends Scene
{
    public UICore(Parent root)
    {
        super(root, 900, 600);
    }
    
}