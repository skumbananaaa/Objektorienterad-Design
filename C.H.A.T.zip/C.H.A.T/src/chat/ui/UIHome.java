/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.ui;

import chat.core.Application;
import chat.core.Warehouse;
import chat.goods.Box;
import chat.goods.Collection;
import chat.goods.Goods;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 *
 * @author Chris
 */
public class UIHome extends UICore
{
    private Warehouse currentWarehouse;
    private Goods currentGoods;
    private boolean editingGoods;
    private boolean stackingGoods;
    private Goods[] currentTemplates;
    
    public UIHome()
    {
        super(new HBox());
        HBox hbox = (HBox) getRoot();
        hbox.setPrefSize(getWidth(), getHeight());
        hbox.setSpacing(5);
        Canvas canvas = new Canvas(600, 600);
        canvas.setOnMouseClicked((MouseEvent event) ->
        {
            this.onMouseClicked((float)event.getSceneX(), (float)event.getSceneY());
        });
        
        VBox vbox = new VBox();
        vbox.setBackground(new Background(new BackgroundFill(Color.GRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        vbox.setPrefSize(300, 600);
        vbox.setPadding(new Insets(10));
        
        hbox.getChildren().addAll(canvas, vbox);
        
        this.currentWarehouse = Application.getDatabaseHandler().getWarehouse(0);
        
        this.draw(canvas.getGraphicsContext2D());
    }
    
    public void onMouseClicked(float x, float y)
    {
        final int tileSize = 50;
        
        if(!editingGoods && !stackingGoods)
        {
            int indexX = -1;
            int indexY = (int) (y / tileSize);

            if(new Rectangle2D(0, 0, tileSize, tileSize * 10).contains(x, y))
            {
                indexX = (int) (x / tileSize);
            }
            else if(new Rectangle2D(150, 0, tileSize * 2, tileSize * 10).contains(x, y))
            {
                indexX = (int) (x / tileSize);
                indexX -= 2;
            }
            else if(new Rectangle2D(350, 0, tileSize * 2, tileSize * 10).contains(x, y))
            {
                indexX = (int) (x / tileSize);
                indexX -= 4;
            }
            else if(new Rectangle2D(550, 0, tileSize, tileSize * 10).contains(x, y))
            {
                indexX = (int) (x / tileSize);
                indexX -= 6;
            }
            if(indexX > -1)
            {
                int index = indexX * 10 + indexY;
                Goods goods = currentWarehouse.getGoodsFromIndex(index);
                if(goods != null)
                {
                    HBox hbox = (HBox) getRoot();
                    VBox vbox = (VBox) hbox.getChildren().get(1);
                    vbox.setUserData(index);
                    this.showProperties(goods);
                }  
            }
        }
    }
    
    private void showProperties(Goods goods)
    {
        this.currentGoods = goods;
        HBox hbox = (HBox) getRoot();
        VBox vbox = (VBox) hbox.getChildren().get(1);
        vbox.getChildren().clear();
        
        vbox.getChildren().addAll(new Label("Goods: " + goods.getClass().getSimpleName()), new Label("Name: " + goods.getName()), new Label("Weight: " + goods.getWeight()), new Label("Price: " + goods.getPrice()));
        
        if(goods instanceof Box)
        {
            Box box = (Box) goods;
            vbox.getChildren().addAll(new Label("Type: " + box.getType()), new Label("Storage Type: " + box.getStorageType()));
        }
        else if(goods instanceof Collection)
        {
            Collection collection = (Collection) goods;
            vbox.getChildren().addAll(new Label("Quantity: " + collection.getQuantity()));
        }
        Button editButton = new Button("Edit");
        editButton.setOnAction((ActionEvent event) ->
        {
            this.setEditingGoods(true);
        });
        
        vbox.getChildren().add(editButton);
    }
    
    private void closeProperties()
    {
        
    }
    
    private void setEditingGoods(boolean value)
    {
        this.editingGoods = value;
        
        if(editingGoods)
        {
            HBox hbox = (HBox) getRoot();
            VBox vbox = (VBox) hbox.getChildren().get(1);
            vbox.getChildren().clear();
            vbox.setSpacing(3);
            
            HBox name = new HBox(new Label("Name:   "), new TextField(currentGoods.getName()));
            HBox weight = new HBox(new Label("Weight: "), new TextField(currentGoods.getWeight() + ""));
            HBox price = new HBox(new Label("Price:     "), new TextField(currentGoods.getPrice() + ""));
            
            vbox.getChildren().addAll(new Label("Goods: " + currentGoods.getClass().getSimpleName()), name, weight, price);

            if(currentGoods instanceof Box)
            {
                Box box = (Box) currentGoods;
                HBox type = new HBox(new Label("Type:     "), new TextField(box.getType() + ""));
                HBox storageType = new HBox(new Label("StorageType: "), new TextField(box.getStorageType() + ""));
                vbox.getChildren().addAll(type, storageType);
            }
            else if(currentGoods instanceof Collection)
            {
                Collection collection = (Collection) currentGoods;
                HBox quantity = new HBox(new Label("Quantity: "), new TextField(collection.getQuantity() + ""));
                vbox.getChildren().addAll(quantity);
            }
            
            Button saveButton = new Button("Save");
            saveButton.setOnAction((ActionEvent event) ->
            {
                String newName = ((TextField)((HBox)vbox.getChildren().get(1)).getChildren().get(1)).getText();
                float newWeight = Float.parseFloat(((TextField)((HBox)vbox.getChildren().get(2)).getChildren().get(1)).getText());
                float newPrice = Float.parseFloat(((TextField)((HBox)vbox.getChildren().get(3)).getChildren().get(1)).getText());
                this.currentGoods.setName(newName);
                this.currentGoods.setWeight(newWeight);
                this.currentGoods.setPrice(newPrice);
                
                if(currentGoods instanceof Box)
                {
                    Box box = (Box) currentGoods;
                    int newType = Integer.parseInt(((TextField)((HBox)vbox.getChildren().get(4)).getChildren().get(1)).getText());
                    int newStorageType = Integer.parseInt(((TextField)((HBox)vbox.getChildren().get(5)).getChildren().get(1)).getText());
                    box.setType(newType);
                    box.setStorageType(newStorageType);
                }
                else if(currentGoods instanceof Collection)
                {
                    Collection collection = (Collection) currentGoods;
                    int newQuantity = Integer.parseInt(((TextField)((HBox)vbox.getChildren().get(4)).getChildren().get(1)).getText());
                    collection.setQuantity(newQuantity);
                }
                this.currentWarehouse.editGoods(currentGoods, (int) vbox.getUserData());
                this.editingGoods = false;
                this.showProperties(currentGoods);
            });
            
            Button moveButton = new Button("Move");
            moveButton.setOnAction((ActionEvent event) ->
            {
                
            });

            vbox.getChildren().addAll(new HBox(saveButton, moveButton));
        }
    }
    
    private void setHighlightGoods(boolean value)
    {
        
    }
    
    private void setCurrentTemplates(Goods[] templates)    
    {
        
    }
    
    private void draw(GraphicsContext graphicsContext)
    {
        final int tileSize = 50;
        
        graphicsContext.setStroke(Color.BLACK);
        
        Goods[] goods = currentWarehouse.getGoods();
        
        int index = 0;
        for(int i = 0; i < 10 && index < goods.length; i++)
        {   
            if(goods[index] != null)
            {
                graphicsContext.drawImage(goods[index].getTexture(), 0, i * tileSize, tileSize, tileSize);
            }
            index++;
        }
        
        for(int i = 0; i < 10 && index < goods.length; i++)
        {   
            if(goods[index] != null)
            {
                graphicsContext.drawImage(goods[index].getTexture(), 150, i * tileSize, tileSize, tileSize);
            }
            index++;
        }
        
        for(int i = 0; i < 10 && index < goods.length; i++)
        {   
            if(goods[index] != null)
            {
                graphicsContext.drawImage(goods[index].getTexture(), 200, i * tileSize, tileSize, tileSize);
            }
            index++;
        }
        
        for(int i = 0; i < 10 && index < goods.length; i++)
        {   
            if(goods[index] != null)
            {
                graphicsContext.drawImage(goods[index].getTexture(), 350, i * tileSize, tileSize, tileSize);
            }
        }
        
        for(int i = 0; i < 10 && index < goods.length; i++)
        {   
            if(goods[index] != null)
            {
                graphicsContext.drawImage(goods[index].getTexture(), 400, i * tileSize, tileSize, tileSize);
            }
            index++;
        }
        
        for(int i = 0; i < 10 && index < goods.length; i++)
        {   
            if(goods[index] != null)
            {
                graphicsContext.drawImage(goods[index].getTexture(), 550, i * tileSize, tileSize, tileSize);
            }
            index++;
        }
        
        for(int i = 0; i < 10; i++)
        {
            graphicsContext.strokeRect(0, i * tileSize, tileSize, tileSize);
            graphicsContext.strokeRect(550, i * tileSize, tileSize, tileSize);
        }
        
        for(int i = 0; i < 10; i++)
        {
            graphicsContext.strokeRect(150, i * tileSize, tileSize, tileSize);
            graphicsContext.strokeRect(200, i * tileSize, tileSize, tileSize);
            
            graphicsContext.strokeRect(350, i * tileSize, tileSize, tileSize);
            graphicsContext.strokeRect(400, i * tileSize, tileSize, tileSize);
        }    
    }
}