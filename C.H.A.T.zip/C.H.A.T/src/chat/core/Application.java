/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.core;

import chat.ui.UIHome;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Chris
 */
public class Application extends javafx.application.Application
{

    private static DatabaseHandler databaseHandler;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        databaseHandler = new DatabaseHandler();
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception
    {
        primaryStage.setTitle("C.H.A.T");
        primaryStage.setScene(new UIHome());
        primaryStage.show();
    }
    
    public static DatabaseHandler getDatabaseHandler()
    {
        return databaseHandler;
    }
}
