/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.core;

import chat.goods.Goods;
import java.util.ArrayList;

/**
 *
 * @author Chris
 */
public class Warehouse
{
    private long uid;
    private String name;
    private Goods[] goods;
    private Goods[] goodsTemplates;

    public Warehouse(long uid, String name, Goods[] goods)
    {
        this.uid = uid;
        this.name = name;
        this.goods = goods;
    }
    
    public void addGoods(Goods goods, int index)
    {
        
    }
    
    public void removeGoods(int index)
    {
        
    }
    
    public void moveGoods(Goods goods, int index)
    {
        
    }
    
    public void editGoods(Goods goods, int index)
    {
        Application.getDatabaseHandler().editGoods(uid, goods, index);
    }
    
    public String getName()
    {
        return name;
    }
    
    public long getUID()
    {
        return uid;
    }
    
    public Goods[] getGoods()
    {
        return goods;
    }
    
    public Goods getGoodsFromIndex(int index)
    {
        if(index > -1 && index < goods.length)
        {
            return goods[index];
        }
        return null;
    }
    
    public Goods[] getGoodsTemplates()
    {
        return goodsTemplates;
    }
}
