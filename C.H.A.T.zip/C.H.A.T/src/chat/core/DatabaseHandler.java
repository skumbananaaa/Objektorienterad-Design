/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.core;

import chat.goods.Box;
import chat.goods.Collection;
import chat.goods.Goods;
import chat.goods.SmallItem;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.util.Pair;

/**
 *
 * @author Chris
 */
public class DatabaseHandler
{
    public Warehouse getWarehouse(long uid)
    {
        try
        {
            List<String> lines = Files.readAllLines(Paths.get("warehouses", uid + ".txt"));
            String name = lines.get(0);
            int nrOfBoxes = Integer.parseInt(lines.get(1));
            int nrOfSmallItems = Integer.parseInt(lines.get(2));
            int nrOfCollections = Integer.parseInt(lines.get(3));
            
            
            Goods[] goods = new Goods[10 * 6];
            
            int startIndex = 4;
            
            for(int i = 0; i < nrOfBoxes; i++)
            {
                String goodsName = lines.get(startIndex++);
                int index = Integer.parseInt(lines.get(startIndex++));
                float weight = Float.parseFloat(lines.get(startIndex++));
                float price = Float.parseFloat(lines.get(startIndex++));
                String texture = lines.get(startIndex++);
                int type = Integer.parseInt(lines.get(startIndex++));
                int storageType = Integer.parseInt(lines.get(startIndex++));
    
                goods[index] = new Box(goodsName, weight, price, texture, type, storageType);
            }
            
            for(int i = 0; i < nrOfSmallItems; i++)
            {
                String goodsName = lines.get(startIndex++);
                int index = Integer.parseInt(lines.get(startIndex++));
                float weight = Float.parseFloat(lines.get(startIndex++));
                float price = Float.parseFloat(lines.get(startIndex++));
                String texture = lines.get(startIndex++);
    
                goods[index] = new SmallItem(goodsName, weight, price, texture);
            }
            
            for(int i = 0; i < nrOfCollections; i++)
            {
                String goodsName = lines.get(startIndex++);
                int index = Integer.parseInt(lines.get(startIndex++));
                float weight = Float.parseFloat(lines.get(startIndex++));
                float price = Float.parseFloat(lines.get(startIndex++));
                String texture = lines.get(startIndex++);
                int quantity = Integer.parseInt(lines.get(startIndex++));
                
                goods[index] = new Collection(goodsName, weight, price, texture, quantity);
            }
            
            return new Warehouse(uid, name, goods);
        }
        catch (IOException ex)
        {
            Logger.getLogger(DatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<Pair<String, Long>> getWarehouses()
    {
        File folder = new File("warehouses");
        File[] listOfFiles = folder.listFiles();

        ArrayList<Pair<String, Long>> warehouses = new ArrayList<>();
        
        for (int i = 0; i < listOfFiles.length; i++)
        {
            if (listOfFiles[i].isFile())
            {
                try
                {
                    System.out.println("Warehouse " + listOfFiles[i].getName());
                    long uid = Long.parseLong(listOfFiles[i].getName().replace(".txt", ""));
                    
                    List<String> lines = Files.readAllLines(Paths.get("warehouses", uid + ".txt"));
                    
                    warehouses.add(new Pair<>(lines.get(0), uid));
                }
                catch (IOException ex)
                {
                    Logger.getLogger(DatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return warehouses;
    }
    
    public void addGoods(long uid, Goods goods, int index)
    {
        
    }
    
    public boolean removeGoods(long uid, int index)
    {
        
        return false;
    }
    
    public boolean editGoods(long uid, Goods goods, int index)
    {
        Warehouse warehouse = getWarehouse(uid);
        if(warehouse != null)
        {
            warehouse.getGoods()[index] = goods;
            
            this.writeWarehouse(warehouse);
        }
        return false;
    }
    
    private void writeWarehouse(Warehouse warehouse)
    {
        ArrayList<Pair<Box, Integer>> boxes = new ArrayList<>();
        ArrayList<Pair<SmallItem, Integer>> smallItems = new ArrayList<>();
        ArrayList<Pair<Collection, Integer>> collections = new ArrayList<>();
        
        for (int i = 0; i < warehouse.getGoods().length; i++)
        {
            Goods goods = warehouse.getGoodsFromIndex(i);
            if(goods != null)
            {
                if(goods instanceof Box)
                {
                    boxes.add(new Pair<>((Box) goods, i));
                }
                else if(goods instanceof SmallItem)
                {
                    smallItems.add(new Pair<>((SmallItem) goods, i));
                }
                else if(goods instanceof Collection)
                {
                    collections.add(new Pair<>((Collection) goods, i));
                }
            }
        }
        
        try
        {
            BufferedWriter writer = new BufferedWriter(new FileWriter(new File("warehouses/" + warehouse.getUID() + ".txt")));
            writer.write(warehouse.getName());
            writer.newLine();
            writer.append(boxes.size() + "");
            writer.newLine();
            writer.append(smallItems.size() + "");
            writer.newLine();
            writer.append(collections.size() + "");
            writer.newLine();
            
            for (Pair<Box, Integer> pair : boxes)
            {
                Box box = pair.getKey();
                String texturePath = box.getTexture().getUrl();
                
                writer.append(box.getName());
                writer.newLine();
                writer.append(pair.getValue() + "");
                writer.newLine();
                writer.append(box.getWeight() + "");
                writer.newLine();
                writer.append(box.getPrice() + "");
                writer.newLine();
                writer.append(texturePath.substring(texturePath.lastIndexOf("/")) + "");
                writer.newLine();
                writer.append(box.getType()+ "");
                writer.newLine();
                writer.append(box.getStorageType()+ "");
                writer.newLine();
            }
            
            for (Pair<SmallItem, Integer> pair : smallItems)
            {
                SmallItem smallItem = pair.getKey();
                String texturePath = smallItem.getTexture().getUrl();
                
                writer.append(smallItem.getName());
                writer.newLine();
                writer.append(pair.getValue() + "");
                writer.newLine();
                writer.append(smallItem.getWeight() + "");
                writer.newLine();
                writer.append(smallItem.getPrice() + "");
                writer.newLine();
                writer.append(texturePath.substring(texturePath.lastIndexOf("/")) + "");
                writer.newLine();
            }
            
            for (Pair<Collection, Integer> pair : collections)
            {
                Collection collection = pair.getKey();
                String texturePath = collection.getTexture().getUrl();
                
                writer.append(collection.getName());
                writer.newLine();
                writer.append(pair.getValue() + "");
                writer.newLine();
                writer.append(collection.getWeight() + "");
                writer.newLine();
                writer.append(collection.getPrice() + "");
                writer.newLine();
                writer.append(texturePath.substring(texturePath.lastIndexOf("/")) + "");
                writer.newLine();
                writer.append(collection.getQuantity()+ "");
                writer.newLine();
            }
            
            writer.flush();
            writer.close();
            
        }
        catch (IOException ex)
        {
            Logger.getLogger(DatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}