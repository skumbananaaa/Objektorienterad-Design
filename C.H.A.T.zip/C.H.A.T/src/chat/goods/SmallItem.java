/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.goods;

/**
 *
 * @author Chris
 */
public class SmallItem extends Goods
{

    public SmallItem(String name, float weight, float price, String texture)
    {
        super(name, weight, price, texture);
    }
}