/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.goods;

/**
 *
 * @author Chris
 */
public class Box extends Goods
{
    private int type;
    private int storageType;

    public Box(String name, float weight, float price, String texture, int type, int storageType)
    {
        super(name, weight, price, texture);
        this.type = type;
        this.storageType = storageType;
    }
    
    public int getType()
    {
        return type;
    }

    public void setType(int type)
    {
        this.type = type;
    }

    public int getStorageType()
    {
        return storageType;
    }

    public void setStorageType(int storageType)
    {
        this.storageType = storageType;
    }
}